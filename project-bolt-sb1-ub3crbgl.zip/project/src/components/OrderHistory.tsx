import { useEffect, useState } from 'react';
import { getUserOrders } from '../lib/orders';
import { Order } from '../types';
import toast from 'react-hot-toast';

export default function OrderHistory() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const userOrders = await getUserOrders();
      setOrders(userOrders);
    } catch (error) {
      toast.error('Failed to load orders');
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No orders found</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <div key={order.id} className="bg-white rounded-lg shadow-md p-4">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="font-medium">Order #{order.id.slice(0, 8)}</h3>
              <p className="text-sm text-gray-500">
                {new Date(order.created_at).toLocaleDateString()}
              </p>
            </div>
            <span className={`px-2 py-1 rounded-full text-sm ${
              order.status === 'delivered' ? 'bg-green-100 text-green-800' :
              order.status === 'preparing' ? 'bg-yellow-100 text-yellow-800' :
              order.status === 'dispatched' ? 'bg-blue-100 text-blue-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
            </span>
          </div>

          <div className="space-y-2">
            {order.items?.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span>{item.quantity}x {item.menu_item_id}</span>
                <span>₹{item.price * item.quantity}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t">
            <div className="flex justify-between">
              <span className="font-medium">Total</span>
              <span className="font-medium">₹{order.total_amount}</span>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Delivery Address: {order.delivery_address}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}