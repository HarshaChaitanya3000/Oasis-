import { ShoppingCart, Menu as MenuIcon, User, History } from 'lucide-react';
import { useState } from 'react';
import { User as SupabaseUser } from '@supabase/supabase-js';

interface NavbarProps {
  cartItemsCount: number;
  onCartClick: () => void;
  user: SupabaseUser | null;
  onAuthClick: () => void;
  onOrderHistoryClick: () => void;
}

export default function Navbar({
  cartItemsCount,
  onCartClick,
  user,
  onAuthClick,
  onOrderHistoryClick,
}: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-lg fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <img
              src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=64&h=64&fit=crop"
              alt="Oasis Restaurant"
              className="h-8 w-8 rounded-full"
            />
            <span className="ml-2 text-xl font-bold text-gray-800">
              Oasis Restaurant
            </span>
          </div>

          <div className="flex items-center space-x-4">
            {user && (
              <button
                onClick={onOrderHistoryClick}
                className="p-2 rounded-full hover:bg-gray-100"
              >
                <History className="h-6 w-6 text-gray-600" />
              </button>
            )}

            <button
              onClick={onAuthClick}
              className="p-2 rounded-full hover:bg-gray-100"
            >
              {user ? (
                <span className="text-sm font-medium text-gray-700">
                  {user.email}
                </span>
              ) : (
                <User className="h-6 w-6 text-gray-600" />
              )}
            </button>

            <button
              onClick={onCartClick}
              className="p-2 rounded-full hover:bg-gray-100 relative"
            >
              <ShoppingCart className="h-6 w-6 text-gray-600" />
              {cartItemsCount > 0 && (
                <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                  {cartItemsCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="ml-2 p-2 rounded-full hover:bg-gray-100 md:hidden"
            >
              <MenuIcon className="h-6 w-6 text-gray-600" />
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a
              href="#menu"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
            >
              Menu
            </a>
            <a
              href="#about"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
            >
              About
            </a>
            <a
              href="#contact"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
            >
              Contact
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}