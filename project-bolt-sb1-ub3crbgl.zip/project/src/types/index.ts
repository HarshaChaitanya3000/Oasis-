export interface MenuItem {
  id: string;
  name: string;
  price: number;
  description?: string;
  category: string;
  image?: string;
  isAvailable: boolean;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
}

export type OrderStatus = 'pending' | 'preparing' | 'dispatched' | 'delivered';

export interface Order {
  id: string;
  user_id: string;
  status: OrderStatus;
  total_amount: number;
  delivery_address: string;
  created_at: string;
  updated_at: string;
  items?: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  menu_item_id: string;
  quantity: number;
  price: number;
  created_at: string;
}