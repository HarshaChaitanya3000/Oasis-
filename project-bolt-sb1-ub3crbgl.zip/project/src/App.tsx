import { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { User } from '@supabase/supabase-js';
import Navbar from './components/Navbar';
import MenuItem from './components/MenuItem';
import Cart from './components/Cart';
import AuthModal from './components/AuthModal';
import OrderHistory from './components/OrderHistory';
import { menuItems, categories } from './data/menu';
import { MenuItem as MenuItemType, CartItem } from './types';
import { supabase } from './lib/supabase';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [showOrderHistory, setShowOrderHistory] = useState(false);

  useEffect(() => {
    // Check current auth status
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleAddToCart = (item: MenuItemType) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(i => i.id === item.id);
      if (existingItem) {
        return prevItems.map(i =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prevItems, { ...item, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (itemId: string, quantity: number) => {
    setCartItems(prevItems =>
      quantity === 0
        ? prevItems.filter(item => item.id !== itemId)
        : prevItems.map(item =>
            item.id === itemId ? { ...item, quantity } : item
          )
    );
  };

  const handleRemoveItem = (itemId: string) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== itemId));
  };

  const handleAuthClick = () => {
    if (user) {
      supabase.auth.signOut();
    } else {
      setIsAuthModalOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar
        user={user}
        cartItemsCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
        onCartClick={() => setIsCartOpen(true)}
        onAuthClick={handleAuthClick}
        onOrderHistoryClick={() => setShowOrderHistory(true)}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        {showOrderHistory ? (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Order History</h2>
              <button
                onClick={() => setShowOrderHistory(false)}
                className="text-orange-600 hover:text-orange-700"
              >
                Back to Menu
              </button>
            </div>
            <OrderHistory />
          </div>
        ) : (
          <>
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                Welcome to Oasis Restaurant
              </h1>
              <p className="text-lg text-gray-600">
                Discover our delicious menu crafted with love
              </p>
            </div>

            {categories.map(category => (
              <section key={category.id} className="mb-12">
                <h2 className="text-2xl font-semibold text-gray-900 mb-6">
                  {category.name}
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {menuItems
                    .filter(item => item.category === category.id)
                    .map(item => (
                      <MenuItem
                        key={item.id}
                        item={item}
                        onAddToCart={handleAddToCart}
                      />
                    ))}
                </div>
              </section>
            ))}
          </>
        )}
      </main>

      {isCartOpen && (
        <Cart
          items={cartItems}
          onClose={() => setIsCartOpen(false)}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
        />
      )}

      {isAuthModalOpen && (
        <AuthModal onClose={() => setIsAuthModalOpen(false)} />
      )}

      <Toaster position="bottom-center" />
    </div>
  );
}

export default App;