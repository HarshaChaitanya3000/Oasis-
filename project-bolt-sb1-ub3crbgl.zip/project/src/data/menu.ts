export const menuItems = [
  // Starters
  {
    id: 'veg-sandwich',
    name: 'Veg Sandwich',
    price: 90,
    category: 'starters',
    description: 'Fresh vegetables with cheese and special sauce',
    isAvailable: true,
  },
  {
    id: 'cheese-chutney-sandwich',
    name: 'Cheese Chutney Sandwich',
    price: 110,
    category: 'starters',
    description: 'Grilled sandwich with cheese and mint chutney',
    isAvailable: true,
  },
  {
    id: 'paneer-sandwich',
    name: 'Paneer Sandwich',
    price: 120,
    category: 'starters',
    description: 'Grilled cottage cheese with vegetables',
    isAvailable: true,
  },

  // Main Course
  {
    id: 'veg-burger',
    name: 'Veg Burger',
    price: 100,
    category: 'mains',
    description: 'Classic vegetable patty with fresh veggies',
    isAvailable: true,
  },
  {
    id: 'paneer-burger',
    name: 'Paneer Burger',
    price: 130,
    category: 'mains',
    description: 'Grilled paneer patty with special sauce',
    isAvailable: true,
  },
  {
    id: 'cheese-burger',
    name: 'Cheese Burger',
    price: 120,
    category: 'mains',
    description: 'Double cheese with vegetable patty',
    isAvailable: true,
  },

  // Beverages
  {
    id: 'mango-shake',
    name: 'Mango Shake',
    price: 80,
    category: 'beverages',
    description: 'Fresh mango shake with ice cream',
    isAvailable: true,
  },
  {
    id: 'chocolate-shake',
    name: 'Chocolate Shake',
    price: 90,
    category: 'beverages',
    description: 'Rich chocolate shake with ice cream',
    isAvailable: true,
  },
  {
    id: 'strawberry-shake',
    name: 'Strawberry Shake',
    price: 80,
    category: 'beverages',
    description: 'Fresh strawberry shake with ice cream',
    isAvailable: true,
  },
];

export const categories = [
  {
    id: 'starters',
    name: 'Starters',
    description: 'Fresh and delicious starters to begin your meal',
  },
  {
    id: 'mains',
    name: 'Main Course',
    description: 'Satisfying main course options',
  },
  {
    id: 'beverages',
    name: 'Beverages',
    description: 'Refreshing drinks and shakes',
  },
];