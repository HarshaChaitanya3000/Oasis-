import { supabase } from './supabase';
import { CartItem, Order, OrderItem } from '../types';

export async function createOrder(items: CartItem[], deliveryAddress: string) {
  const totalAmount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Start a Supabase transaction
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert({
      total_amount: totalAmount,
      delivery_address: deliveryAddress,
    })
    .select()
    .single();

  if (orderError) throw orderError;

  // Create order items
  const orderItems = items.map(item => ({
    order_id: order.id,
    menu_item_id: item.id,
    quantity: item.quantity,
    price: item.price,
  }));

  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(orderItems);

  if (itemsError) throw itemsError;

  return order;
}

export async function getUserOrders() {
  const { data: orders, error: ordersError } = await supabase
    .from('orders')
    .select(`
      *,
      items:order_items(*)
    `)
    .order('created_at', { ascending: false });

  if (ordersError) throw ordersError;

  return orders as Order[];
}

export async function getOrderById(orderId: string) {
  const { data: order, error } = await supabase
    .from('orders')
    .select(`
      *,
      items:order_items(*)
    `)
    .eq('id', orderId)
    .single();

  if (error) throw error;

  return order as Order;
}